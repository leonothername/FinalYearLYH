//
//  ViewController.swift
//  PokemonCards3D
//
//  Created by leon Yat Howe on 15/01/2022.
//

import UIKit
import SceneKit
import ARKit



class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!
    
    
    //private let database = Database.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        sceneView.delegate = self
        
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = true
        
        sceneView.autoenablesDefaultLighting = true
        
        
     
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        
        // Next I need to change the session configuration of the ARSession from world tracking configuration to AR image Tracking Configuration, this is because I am using a different modal.
        
        //I'm looking for planes in the real world in vertical or horizontal planes, I'm looking for specific images we provide.
        
        
        //Now, after we've set up the configuration, the next thing I need to do is tell my application that the images that should be tracked are located here.
        
        // Let's create something called image to track and let's set it equal to a brand-new object of the type ARReferenceImage.
        
        // This is the image to be recognized in the real world environment during the world tracking ARSession.
        
        // This is a new reference image object, and I'll make use of the referenceImages mrthod so that it loads all the repaint images in the specified AR resource group.
        
        let configuration = ARImageTrackingConfiguration()
        
        if let imageToTrack = ARReferenceImage.referenceImages(inGroupNamed: "Pokemon Cards", bundle: Bundle.main) {
            
            configuration.trackingImages = imageToTrack
            
            configuration.maximumNumberOfTrackedImages = 7
            
            print("Images Successfully Added")
        }

 
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }

    // MARK: - ARSCNViewDelegate
    
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        
        let node = SCNNode()
        
        
       
        
        if let imageAnchor = anchor as? ARImageAnchor {
            
            //print(imageAnchor.referenceImage.name)
            
            let plane = SCNPlane(width: imageAnchor.referenceImage.physicalSize.width, height: imageAnchor.referenceImage.physicalSize.height)
            
            let planeNode = SCNNode(geometry: plane)
           
            
            plane.firstMaterial?.diffuse.contents = UIColor(white: 1.0, alpha: 0.5)
            
            //Card size
            
             planeNode.eulerAngles.x = -.pi / 2
                    
            
            node.addChildNode(planeNode)
            
            if imageAnchor.referenceImage.name == "Jolteon1" {
                
                if let pokeScene = SCNScene(named: "art.scnassets/Jolteon_ColladaMax.usdz") {
                    
                    if let PokeNode  = pokeScene.rootNode.childNodes.first {
                        
                        
                        PokeNode.eulerAngles.x = .pi / 2
                        
                        planeNode.addChildNode(PokeNode)
                    }
                }
            }
            
            
            if imageAnchor.referenceImage.name == "Jolteon2" {
                
                if let pokeScene = SCNScene(named: "art.scnassets/Jolteon_ColladaMax.usdz") {
                    
                    if let PokeNode  = pokeScene.rootNode.childNodes.first {
                        
                        
                        PokeNode.eulerAngles.x = .pi / 2
                        
                        planeNode.addChildNode(PokeNode)
                    }
                }
            }
            
            
            if imageAnchor.referenceImage.name == "Jolteon3" {
                
                if let pokeScene = SCNScene(named: "art.scnassets/Jolteon_ColladaMax.usdz") {
                    
                    if let PokeNode  = pokeScene.rootNode.childNodes.first {
                        
                        
                        PokeNode.eulerAngles.x = .pi / 2
                        
                        planeNode.addChildNode(PokeNode)
                    }
                }
            }
            
            
            
            if imageAnchor.referenceImage.name == "Espeon1" {
                
                if let pokeScene = SCNScene(named: "art.scnassets/Espeon_ColladaMax.usdz") {
                    
                    if let PokeNode  = pokeScene.rootNode.childNodes.first {
                        
                        
                        PokeNode.eulerAngles.x = .pi / 2
                        
                        planeNode.addChildNode(PokeNode)
                    }
                }
            }
            
            
            if imageAnchor.referenceImage.name == "Espeon2" {
                
                if let pokeScene = SCNScene(named: "art.scnassets/Espeon_ColladaMax.usdz") {
                    
                    if let PokeNode  = pokeScene.rootNode.childNodes.first {
                        
                        
                        PokeNode.eulerAngles.x = .pi / 2
                        
                        planeNode.addChildNode(PokeNode)
                    }
                }
            }
            
            
            if imageAnchor.referenceImage.name == "Espeon3" {
                
                if let pokeScene = SCNScene(named: "art.scnassets/Espeon_ColladaMax.usdz") {
                    
                    if let PokeNode  = pokeScene.rootNode.childNodes.first {
                        
                        
                        PokeNode.eulerAngles.x = .pi / 2
                        
                        planeNode.addChildNode(PokeNode)
                    }
                }
            }
            
            
            
        }
        
        
        return node
    }
}
